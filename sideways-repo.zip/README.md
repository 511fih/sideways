<div align="center">

# SIDEWAYS

**A top-down drift racer in a single HTML file. No rivals to beat, just you, the clock and your own ghost.**

![License: MIT](https://img.shields.io/badge/license-MIT-c2410c)
![Single file](https://img.shields.io/badge/single-HTML%20file-1c1d20)
![Dependencies: none](https://img.shields.io/badge/dependencies-none-2f5a43)
![Tracks: 4](https://img.shields.io/badge/tracks-4-3a3d44)

<img src="docs/gameplay.gif" alt="Gameplay: a yellow car drifting through corners while chasing a ghost car" width="720">

[**Play it now**](https://YOUR-USERNAME.github.io/YOUR-REPO/) · [Controls](#controls) · [Tracks](#tracks) · [Garage](#the-garage) · [Run it yourself](#run-it-yourself)

</div>

---

## The idea

Three laps. One clock. Every race, your fastest run is saved as a ghost. Next time out you chase it with a live time delta showing whether you're gaining or losing. Hold **Space** to break the rear tires loose, slide through corners without lifting, and shave tenths off your best.

<div align="center">
<img src="docs/racing.png" alt="A yellow car mid-drift with skid marks, chasing a grey ghost car, with a +0.06 delta on the HUD" width="860">
</div>

## Features

- **Drift handling.** The handbrake loosens the tires so the car swings out and keeps its speed through a corner. Skid marks stay on the tarmac, and a drift-points counter runs while you slide.
- **Ghost racing.** Race a translucent replay of your fastest finished race, with a live delta at the top right: **green** means you're ahead, **red** means you're behind.
- **High scores.** The top 5 fastest races and top 5 fastest laps for every track, with the date you set them.
- **Four tracks**, from a fast oval to a tight, technical snake.
- **Car weight.** Pick a light, standard or heavy car in the Garage and feel the trade-off.
- **Touch controls** appear automatically on phones and tablets.
- **Zero dependencies.** One HTML file, no build step.

<div align="center">
<img src="docs/ui-overview.png" alt="The main menu, the Garage screen and the results screen" width="900">
</div>

## Controls

| Action | Keyboard | Touch |
| --- | --- | --- |
| Accelerate | Up arrow or W | Gas |
| Brake and reverse | Down arrow or S | Brake |
| Steer | Left and right arrows, or A and D | Left and Right |
| Drift | Space | Drift |
| Respawn on track | R | |
| Back to menu | Esc | |

**Drift tips:** Brake a little before the corner, turn in, then tap or hold Space while steering to swing the back end round. Let go of Space to grip up again and power out. Going off the tarmac slows you sharply, so a clean slide beats a wide one.

## Tracks

<div align="center">
<img src="docs/tracks.png" alt="Maps of the four tracks: Classic, Speedway, Serpentine and Delta" width="760">
</div>

| Track | Character |
| --- | --- |
| **Classic** | A balanced mix of sweepers and a tight hairpin section. The place to start. |
| **Speedway** | Fast and open with a single chicane. Rewards a heavy car and a brave right foot. |
| **Serpentine** | A long, technical layout built around a big hairpin in the middle. |
| **Delta** | Long sweeping corners with a quick esses section on the way down. |

## The Garage

Open **Customise car** from the main menu to change your car's weight.

| Weight | Top speed | Handling |
| --- | --- | --- |
| **Light** | Slightly lower | Better grip and quicker turning |
| **Standard** | The baseline | The baseline |
| **Heavy** | Slightly higher | Harder to turn and quicker to slide |

Each weight keeps its own ghost and high scores for every track, so your times always compare like with like.

## Run it yourself

There is no build step and nothing to install. Open `index.html` in a modern browser.

To serve it locally instead:

```sh
python3 -m http.server 8000
```

Then visit http://localhost:8000.

### Deploy with GitHub Pages

1. Put the game in the root of your repo as `index.html`.
2. In the repo, open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, then select your main branch and the `/ (root)` folder.
4. After a minute or so the game is live at `https://<your-username>.github.io/<repo-name>/`.

Then update the **Play it now** link at the top of this README.

## How it works

- **Rendering:** Everything is drawn on one HTML canvas. The track and skid marks are rendered once to offscreen canvases and reused each frame.
- **Track:** A closed Catmull-Rom spline defines each circuit. The road, kerbs and start line are drawn from it, and your position and lap progress are measured against it.
- **Physics:** A fixed 60 Hz step splits the car's velocity into a forward part and a sideways part. Sideways velocity is damped by a grip value, which the handbrake lowers to let the car slide. Car weight scales top speed and grip.
- **Ghost:** Your position and heading are recorded every physics step. Because the step is fixed, the replay stays in sync. The delta compares your time with the ghost's time at the same point on the track.

## Saved data

The ghost and high scores are stored separately for each track and each car weight in your browser's `localStorage`. The Classic track uses the keys `sideways-ghost` and `sideways-scores`, and the other tracks add their track number to the end (for example `sideways-ghost-2`). Non-standard weights add `-light` or `-heavy` after that (for example `sideways-ghost-2-heavy`). Data is specific to each browser and each site address, and clearing site data removes it.

## Repo layout

```
index.html     the whole game
docs/          screenshots and the gameplay GIF used in this README
LICENSE        MIT
README.md      you are here
```

## Credits

The game uses the [Big Shoulders Display](https://fonts.google.com/specimen/Big+Shoulders+Display) and [Barlow](https://fonts.google.com/specimen/Barlow) fonts from Google Fonts, both under the SIL Open Font License.

## License

Released under the [MIT License](LICENSE).
